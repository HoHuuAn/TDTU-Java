# Class Stack
class Stack:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def __str__(self):
        return ' '.join([str(i) for i in self.items])

    def push(self, item): 
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self): 
        return self.items[len(self.items)-1]
    
    def size(self):
        return len(self.items)

    # def print_stack(self):
    #     for item in self.items:
    #         print(item)

# Class Queue
class Queue: 
    def __init__(self): 
        self.items = [] 

    def __str__(self):
        return ' '.join([str(i) for i in self.items])
  
    def isEmpty(self):
        return self.items == [] 
  
    def enqueue(self, item): 
        self.items.append(item) 
  
    def dequeue(self): 
        return self.items.pop(0) 
  
    def size(self): 
        return len(self.items) 

# Class PriorityQueue
class PriorityQueue:
    def __init__(self):
        self.queue = []
 
    def __str__(self):
        return ' '.join([str(i) for i in self.queue])
 
    # for checking if the queue is empty
    def isEmpty(self):
        return len(self.queue) == 0
 
    # for inserting an element in the queue
    def insert(self, data):
        self.queue.append(data)
 
    # for popping an element based on Priority
    def delete(self):
        try:
            max_val = 0
            for i in range(len(self.queue)):
                if self.queue[i] > self.queue[max_val]:
                    max_val = i
            item = self.queue[max_val]
            del self.queue[max_val]
            return item
        except IndexError:
            print()
            exit()

jjjjjjjjjjjjjj 