def UCS():
    return
