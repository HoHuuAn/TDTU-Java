import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math

df = pd.read_csv('input.csv')

# plt.scatter(df['height'], df['age'])
# plt.xlabel('height')
# plt.ylabel('age')
# plt.show()


def Euc(df,index = 0):
    target = df.iloc[index]
    dis_list = []
    for i in range (10):
        if i == index: continue
        friend = df.iloc[i]
        one_row = list([(math.sqrt((target[0]-friend[0])**2 + target[1]-friend[1])**2), friend[2]])
        dis_list.append(one_row)
    return dis_list

a = Euc(df)
a.sort()
# print(a)
print (a[:3])
